from .dni import DNI

__all__ = ['DNI']
